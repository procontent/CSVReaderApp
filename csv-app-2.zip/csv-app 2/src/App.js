import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import CSVReader from './components/CSVReader';
var App = function () {
    return (_jsxs("div", { children: [_jsx("h1", { children: "CSV File Reader" }), _jsx(CSVReader, {})] }));
};
export default App;
